package one;
import java.io.*;
import java.util.List;
import java.util.Scanner;
public class guihuan {
	guihuan(String name){
		Scanner sc = new Scanner (System.in);
		System.out.println("����������Ҫ�黹���鼮��");
		String bookname = sc.next();
		String n = name;
		try {
//			���Ľ�������
//		 	-----------
			FileInputStream fos = new FileInputStream("Jieyelist.dat");
			ObjectInputStream oos = new ObjectInputStream(fos);
			List<jieyuegeti> jilu =(List<jieyuegeti>) oos.readObject();
			int t =0;
			for(int i=0;i<jilu.size();i++) {
				if(jilu.get(i).book.bookname.equals(bookname)&&jilu.get(i).stu.name.equals(n)) {
					jilu.remove(i);
					t=1;
					i--;
				}
			}
			if (t==0) {
				System.out.println("��δ���Ĺ���ͼ�飡");
			}
			if(t==1) {
				System.out.println("�黹��ɣ�");
			}
			FileOutputStream fos1 = new FileOutputStream("Jieyelist.dat");
			ObjectOutputStream oos1 = new ObjectOutputStream(fos1);
			oos1.writeObject(jilu);
			
//			�����������
//		 	-----------			
			
			FileInputStream fis = new FileInputStream("Book.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);
			List <Book>books = (List <Book>)ois.readObject();
//			int t =0;
			for(int i=0;i<books.size();i++) {
				if(books.get(i).bookname.equals(bookname)) {
					if(books.get(i).islend!=true) {
						books.get(i).islend=true;
						t=1;
						break;
					}
					
				}
			}
//			if(t==0) {
//				System.out.println("��δ���Ĺ���ͼ�飡");
//			}
			FileOutputStream fis1 = new FileOutputStream("Book.dat");
			ObjectOutputStream ois1 = new ObjectOutputStream(fis1);
			ois1.writeObject(books);
			
			fos.close();
			oos.close();
			fos1.close();
			oos1.close();
			fis.close();
			ois.close();
			fis1.close();
			ois1.close();
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}

	}
}
