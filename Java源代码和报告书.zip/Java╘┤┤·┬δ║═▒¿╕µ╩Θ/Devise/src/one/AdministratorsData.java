package one;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class AdministratorsData {
	public static String administratorsdata(String name) throws IOException {
		FileReader fr = new FileReader("data.txt");
		BufferedReader br = new BufferedReader(fr);
		String sum = br.readLine();
		while(sum!=null) {
			String []stuarr = sum.split("  ");
			if(name.equals(stuarr[0].toString())) {
				return stuarr[1].toString();
			}
			sum = br.readLine();
		}
		return "0";
	}

}