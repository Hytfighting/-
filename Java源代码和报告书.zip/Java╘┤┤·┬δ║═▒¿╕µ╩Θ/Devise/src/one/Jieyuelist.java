package one;
import java.io.*;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
public class Jieyuelist implements Serializable {
//	Book book;
//	Student stu;
//	String time;
	List<jieyuegeti> jilu;
	public Jieyuelist() {

		try {
			FileInputStream fos = new FileInputStream("Jieyelist.dat");
			ObjectInputStream oos = new ObjectInputStream(fos);
			jilu =(List<jieyuegeti>) oos.readObject();
			fos.close();
			oos.close();
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}

	}	
	public void addgeti(jieyuegeti j){
		jilu.add(j);
	}

	public void write() {
		try {
			FileOutputStream fos = new FileOutputStream("Jieyelist.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			System.out.println("-------------------------------------------------------------");
			oos.writeObject(jilu);
			oos.close();
			fos.close();
		}
		catch(IOException e) {
			System.out.println(e.toString());
		}
		
	}
	public jieyuegeti [] read() {
		jieyuegeti [] jyg = new jieyuegeti[jilu.size()];
		for(int i=0;i<jilu.size();i++) {
			jyg[i]=jilu.get(i);
		}
		return jyg;
	}

}
