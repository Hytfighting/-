package one;
import java.io.Serializable;
public class Book implements Serializable{
	String bookname;
	String writer;
	String press;
	double price;
	boolean islend;
	public Book(String bookname, String writer, String press, double price) {
		super();
		this.bookname = bookname;
		this.writer = writer;
		this.press = press;
		this.price = price;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getPress() {
		return press;
	}
	public void setPress(String press) {
		this.press = press;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean isIslend() {
		return islend;
	}
	public void setIslend(boolean islend) {
		this.islend = islend;
	}
	@Override
	public String toString() {
		if(this.islend==true) {
			return "��"+bookname+"��" + "    ���ߣ�" + writer + "    �����磺" + press + "    �۸�" + price
					+ "    ״̬��" + "�ڹ�";
		}
		else {
			return "��"+bookname+"��" + "    ���ߣ�" + writer + "    �����磺" + press + "    �۸�" + price
					+ "    ״̬��" + "�ѽ��";
		}
		
	}
	
}
