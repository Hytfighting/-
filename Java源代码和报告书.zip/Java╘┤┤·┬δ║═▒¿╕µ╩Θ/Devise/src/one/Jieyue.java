package one;
import java.util.Scanner;
import java.io.Serializable;
public class Jieyue implements operate{
	public void operatesystem() {
		
	}
	public void operatesystem(String name,String Id) {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("������������");
			String bookname = sc.next();
			Jieyuelist jyl = new Jieyuelist();
			Library l = new Library();
			int c=0;
			for(int i=0;i<l.books.size();i++) {

				if(l.books.get(i).bookname.equals(bookname)) {
					if(l.books.get(i).islend==false) {
						c=1;
					}
					else {
						jyl.addgeti(new jieyuegeti(l.books.get(i),new Student(name,Id))); 
						l.books.get(i).islend=false;
						jyl.write();
						c=2;
						System.out.println("������ɣ�");
						break;
					}
					
				}
			}
			l.writer();
			if(c==0) {
				System.out.println("���޴��飡");
			}
			if(c==1) {
				System.out.println("������ȫ�������");
			}
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
		
	}

}
