package one;
import java.util.List;
import java.util.ArrayList;
import java.io.*;
public class Library {
	List<Book> books;
	Library (){
		try {
			FileInputStream fis = new FileInputStream("Book.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);
			books = (List <Book>)ois.readObject();
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	void add(Book b) {
		books.add(b);
	}
	void writer() throws IOException{

		FileOutputStream fos = new FileOutputStream("Book.dat");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(books);
		oos.close();
		fos.close();
	}
	Book[] reader() throws IOException,ClassNotFoundException {
		Book [] bookArray = new Book[books.size()];
		for(int i=0;i<books.size();i++) {
			bookArray[i]=books.get(i);
		}
		return bookArray;
	}

}
