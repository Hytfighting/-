package one;
import java.io.*;
public class Xianshi implements operate{
	public void operatesystem() {
		try {
			Library l = new Library();
			Book[] b = l.reader();
			for(int i=0;i<b.length;i++) {
				System.out.println(b[i]);
				System.out.println("------------------------------------------------------------------------");
			}
		}
		catch(IOException e) {
			System.out.println(e.toString());
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.toString());
		}
	}

}
