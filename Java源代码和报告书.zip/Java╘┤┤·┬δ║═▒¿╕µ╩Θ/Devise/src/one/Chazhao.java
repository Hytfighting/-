package one;
import java.io.*;
import java.util.Scanner;
public class Chazhao implements operate{
	public void operatesystem() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("����������Ҫ�����鼮��������");
			String bookname = sc.next();
			Library l =new Library();
			Book[] b =l.reader();
			int t =0;
			for(int i=0;i<b.length;i++) {
				
				if(b[i].bookname.equals(bookname)) {
					t=1;
					System.out.println(b[i]);
				}
			}
			if(t==0) {
				System.out.println("���޴��飡");
			}
		}
		catch(IOException e) {
			System.out.println(e.toString());
		}
		catch(ClassNotFoundException e) {
			System.out.println(e.toString());
		}
	}
	
	
}
