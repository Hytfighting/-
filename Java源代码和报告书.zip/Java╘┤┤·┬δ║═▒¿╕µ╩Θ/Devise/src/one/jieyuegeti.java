package one;

import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.Serializable;
import java.text.SimpleDateFormat;
public class jieyuegeti implements Serializable {
	Book book;
	Student stu;
	Date time;
	Date newtime;
	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public jieyuegeti(Book book, Student stu) {
		super();
		this.book = book;
		this.stu = stu;
		this.time = new Date();
		Calendar c =Calendar.getInstance();
		c.setTime(time);
		c.add(Calendar.MONTH, 1);
		newtime = c.getTime();
		this.book.islend=false;

}
	public String toString() {
		return book.toString() +"\n"+ stu.toString()+"\n"+"����ʱ�䣺 "+df.format(time)+"\n"+"�黹ʱ�䣺 "+df.format(newtime)+"\n"+"-------------------------------------------------------------";
	}
}
