package one;

import java.io.Serializable;

public class Student implements Serializable {
	String name;
	String Id;
	Student(String name,String Id){
		this.name=name;
		this.Id=Id;
	}
	@Override
	public String toString() {
		return "�����ˣ� "+name + "   ѧ�ţ� "+Id;
	}
	

}
