package one;
public interface operate {
	abstract void operatesystem();

}
