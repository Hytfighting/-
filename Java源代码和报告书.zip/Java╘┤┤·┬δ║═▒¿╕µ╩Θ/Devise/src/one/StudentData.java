package one;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;

public class StudentData {
	public static String studentData(String name) throws IOException {
		FileReader fr = new FileReader("studentdata.dat");
		BufferedReader br = new BufferedReader(fr);
		String sum = br.readLine();
		while(br!=null) {
			String []stuarr = sum.split("  ");
			if(name.equals(stuarr[0].toString())) {
				return stuarr[1];
			}
			sum=br.readLine();
		}
		return "0";
	}

}
